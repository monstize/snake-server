# EMOJI SNAKE — multiplayer em tempo real

- `server/` — servidor Node + WebSocket (autoritativo: movimento, comida, colisões, bots e pontuação são decididos aqui).
- `public/emoji-snake.html` — cliente (Canvas, joystick, minimapa). Arquivo único.
- `server/snake.sql` — ranking do Emoji Snake (tabela separada do Quica, opcional).

## 1. Subir o servidor (Render, exemplo)
1. Coloque a pasta `server/` num repositório do GitHub.
2. Em render.com: New → Web Service → escolha o repositório. Build: `npm install`. Start: `npm start`.
3. Variáveis de ambiente (todas opcionais, mas recomendadas):
   - `ALLOWED_ORIGINS` = `https://notasbeta.online,https://www.notasbeta.online` (separados por vírgula)
   - `SUPABASE_URL` e `SUPABASE_SERVICE_ROLE_KEY` (só para o ranking persistente; rode `snake.sql` no SQL Editor antes)
4. Anote o endereço, ex.: `https://emoji-snake.onrender.com`. O endereço WebSocket é o mesmo com `wss://`.
Planos gratuitos costumam "dormir" sem uso e ter limites: confira as condições atuais do provedor. Fly.io e Railway servem também.

## 2. Ligar o cliente
Copie `public/emoji-snake.html` para a pasta pública do site e, antes do `<script>` do jogo, defina `window.SNAKE_WS='wss://SEU-SERVIDOR'` (ou troque o texto `SEU-SERVIDOR.onrender.com` no arquivo).
Botão "Menu principal": chama `window.SNAKE_EXIT()` se existir; dentro de iframe envia `postMessage({quica:'menu'})`; sozinho, vai para `/quica`.

## Regras do jogo (todas no servidor)
- Velocidade fixa de 170 px/s; o cliente só envia o ângulo desejado.
- Cabeça x corpo: se quem encostou tem ao menos 1,5x a massa do dono do corpo, come o dono; senão, quem encostou morre.
- Cabeça x cabeça: o maior (+15%) come; massas parecidas, nada acontece. Borda do mapa não mata.
- Quem come ganha 50% da massa do eliminado; o resto vira comida no mapa. Cada segmento usa o emoji do dono.
- Bots (níveis 0–3) aparecem como "· IA" e completam a sala até ~14 cobrinhas. Sala com até 20 humanos; novas salas abrem sozinhas.
- Proteção de 3 s ao nascer, e novas cobrinhas nascem longe das outras.
- Limites: 60 mensagens/s por conexão (acima disso, desconecta), apelido filtrado, emoji só da lista.

## Testes
`cd server && npm install && npm test` (22 testes: regras, bots, 2 clientes WebSocket reais).
